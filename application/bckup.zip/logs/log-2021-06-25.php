<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-25 00:00:07 --> Could not find the language line "donate_book"
ERROR - 2021-06-25 00:00:09 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\bookscafe-ci_old\system\libraries\Email.php 1902
ERROR - 2021-06-25 00:00:24 --> Could not find the language line "donate_book"
ERROR - 2021-06-25 00:00:26 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\bookscafe-ci_old\system\libraries\Email.php 1902
ERROR - 2021-06-25 00:00:48 --> Could not find the language line "donate_book"
ERROR - 2021-06-25 00:00:54 --> Could not find the language line "book_total_label"
ERROR - 2021-06-25 00:02:06 --> Could not find the language line "book_total_label"
ERROR - 2021-06-25 00:02:27 --> Could not find the language line "book_plan"
ERROR - 2021-06-25 00:02:29 --> Could not find the language line "donate_book"
ERROR - 2021-06-25 00:02:52 --> Could not find the language line "donate_book"
ERROR - 2021-06-25 00:03:18 --> Could not find the language line "donate_book"
ERROR - 2021-06-25 00:03:30 --> Could not find the language line "donate_book"
ERROR - 2021-06-25 00:03:51 --> Could not find the language line "donate_book"
ERROR - 2021-06-25 00:04:17 --> Could not find the language line "donate_book"
