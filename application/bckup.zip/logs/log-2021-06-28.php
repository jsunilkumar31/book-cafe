<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-28 11:03:05 --> Could not find the language line "Faqs"
ERROR - 2021-06-28 11:05:31 --> Could not find the language line "Faqs"
ERROR - 2021-06-28 16:07:45 --> Could not find the language line "donate_book"
ERROR - 2021-06-28 18:12:35 --> Could not find the language line "donate_book"
ERROR - 2021-06-28 18:12:42 --> Could not find the language line "book_total_label"
ERROR - 2021-06-28 18:12:48 --> Could not find the language line "Faqs"
ERROR - 2021-06-28 18:12:53 --> Could not find the language line "book_total_label"
ERROR - 2021-06-28 18:12:58 --> Could not find the language line "book_total_label"
