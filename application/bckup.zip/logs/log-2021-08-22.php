<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-22 01:10:39 --> Could not find the language line "book_total_label"
ERROR - 2021-08-22 04:37:58 --> Could not find the language line "book_total_label"
ERROR - 2021-08-22 04:37:58 --> Could not find the language line "book_total_label"
ERROR - 2021-08-22 04:37:58 --> Could not find the language line "book_total_label"
ERROR - 2021-08-22 04:37:58 --> Could not find the language line "book_total_label"
ERROR - 2021-08-22 09:56:21 --> Could not find the language line "book_total_label"
ERROR - 2021-08-22 13:44:22 --> Could not find the language line "book_total_label"
ERROR - 2021-08-22 13:44:32 --> Could not find the language line "book_total_label"
ERROR - 2021-08-22 13:48:48 --> Could not find the language line "book_total_label"
ERROR - 2021-08-22 13:49:22 --> Could not find the language line "book_total_label"
ERROR - 2021-08-22 16:55:24 --> Could not find the language line "book_total_label"
ERROR - 2021-08-22 17:10:50 --> Could not find the language line "book_total_label"
