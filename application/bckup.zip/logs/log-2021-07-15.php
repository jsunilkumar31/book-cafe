<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-15 23:05:04 --> Could not find the language line "book_total_label"
