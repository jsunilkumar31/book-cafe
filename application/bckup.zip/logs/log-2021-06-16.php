<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
ERROR - 2021-06-16 09:02:50 --> Could not find the language line "language"
ERROR - 2021-06-16 09:03:22 --> Could not find the language line "language"
ERROR - 2021-06-16 09:06:36 --> Could not find the language line "language"
ERROR - 2021-06-16 09:06:48 --> Could not find the language line "language"
ERROR - 2021-06-16 09:09:50 --> Could not find the language line "language"
ERROR - 2021-06-16 09:09:59 --> Could not find the language line "language"
ERROR - 2021-06-16 09:10:14 --> Could not find the language line "language"
ERROR - 2021-06-16 09:11:05 --> Could not find the language line "language"
ERROR - 2021-06-16 09:11:41 --> Could not find the language line "language"
ERROR - 2021-06-16 09:11:57 --> Could not find the language line "language"
ERROR - 2021-06-16 09:12:23 --> Could not find the language line "language"
ERROR - 2021-06-16 09:17:30 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 09:17:40 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 09:17:53 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 09:18:01 --> Could not find the language line "language"
ERROR - 2021-06-16 09:37:50 --> Could not find the language line "language"
ERROR - 2021-06-16 09:38:13 --> Could not find the language line "language"
ERROR - 2021-06-16 09:39:56 --> Could not find the language line "language"
ERROR - 2021-06-16 09:40:39 --> Could not find the language line "language"
ERROR - 2021-06-16 09:43:33 --> Could not find the language line "language"
ERROR - 2021-06-16 09:44:44 --> Could not find the language line "language"
ERROR - 2021-06-16 09:44:49 --> Could not find the language line "language"
ERROR - 2021-06-16 09:44:49 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 54
ERROR - 2021-06-16 09:44:49 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 54
ERROR - 2021-06-16 09:44:49 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 62
ERROR - 2021-06-16 09:44:49 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 62
ERROR - 2021-06-16 09:44:49 --> Severity: Notice --> Trying to get property 'created_on' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 63
ERROR - 2021-06-16 09:44:49 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 84
ERROR - 2021-06-16 09:44:49 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 107
ERROR - 2021-06-16 09:44:49 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 107
ERROR - 2021-06-16 09:45:54 --> Could not find the language line "language"
ERROR - 2021-06-16 09:46:13 --> Could not find the language line "language"
ERROR - 2021-06-16 09:46:46 --> Could not find the language line "language"
ERROR - 2021-06-16 09:47:00 --> Could not find the language line "language"
ERROR - 2021-06-16 09:47:04 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 09:48:24 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 09:48:24 --> Severity: Notice --> Undefined variable: page_title C:\xampp\htdocs\bookscafe-ci_old\application\views\template_morden\header.php 10
ERROR - 2021-06-16 09:48:24 --> Severity: Notice --> Undefined variable: body_class C:\xampp\htdocs\bookscafe-ci_old\application\views\template_morden\header.php 26
ERROR - 2021-06-16 09:48:24 --> Severity: Notice --> Undefined variable: page_title C:\xampp\htdocs\bookscafe-ci_old\application\views\template_morden\header.php 97
ERROR - 2021-06-16 09:48:24 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\bookscafe-ci_old\application\views\template_morden\navigation.php 16
ERROR - 2021-06-16 09:48:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bookscafe-ci_old\application\views\template_morden\navigation.php 16
ERROR - 2021-06-16 09:48:24 --> Severity: Notice --> Undefined variable: view_file C:\xampp\htdocs\bookscafe-ci_old\application\controllers\Home.php 68
ERROR - 2021-06-16 09:48:24 --> Severity: Notice --> Undefined variable: _ci_file C:\xampp\htdocs\bookscafe-ci_old\application\third_party\MX\Loader.php 347
ERROR - 2021-06-16 09:48:52 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 09:48:52 --> Severity: Notice --> Undefined variable: page_title C:\xampp\htdocs\bookscafe-ci_old\application\views\template_morden\header.php 10
ERROR - 2021-06-16 09:48:52 --> Severity: Notice --> Undefined variable: body_class C:\xampp\htdocs\bookscafe-ci_old\application\views\template_morden\header.php 26
ERROR - 2021-06-16 09:48:52 --> Severity: Notice --> Undefined variable: page_title C:\xampp\htdocs\bookscafe-ci_old\application\views\template_morden\header.php 97
ERROR - 2021-06-16 09:48:52 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\bookscafe-ci_old\application\views\template_morden\navigation.php 16
ERROR - 2021-06-16 09:48:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bookscafe-ci_old\application\views\template_morden\navigation.php 16
ERROR - 2021-06-16 09:50:03 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 09:50:03 --> Severity: Notice --> Undefined variable: body_class C:\xampp\htdocs\bookscafe-ci_old\application\views\template_morden\header.php 26
ERROR - 2021-06-16 09:50:03 --> Severity: Notice --> Undefined variable: menu C:\xampp\htdocs\bookscafe-ci_old\application\views\template_morden\navigation.php 16
ERROR - 2021-06-16 09:50:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bookscafe-ci_old\application\views\template_morden\navigation.php 16
ERROR - 2021-06-16 09:51:23 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 09:51:23 --> Severity: Notice --> Undefined variable: login C:\xampp\htdocs\bookscafe-ci_old\application\controllers\Home.php 90
ERROR - 2021-06-16 09:51:51 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 09:52:02 --> Could not find the language line "contacts"
ERROR - 2021-06-16 09:53:20 --> Could not find the language line "contacts"
ERROR - 2021-06-16 09:53:25 --> Could not find the language line "language"
ERROR - 2021-06-16 09:53:33 --> Could not find the language line "language"
ERROR - 2021-06-16 09:53:50 --> Could not find the language line "language"
ERROR - 2021-06-16 09:54:15 --> Could not find the language line "language"
ERROR - 2021-06-16 09:55:42 --> Could not find the language line "language"
ERROR - 2021-06-16 09:56:41 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 09:56:44 --> Could not find the language line "contacts"
ERROR - 2021-06-16 09:58:07 --> Could not find the language line "language"
ERROR - 2021-06-16 09:58:07 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 54
ERROR - 2021-06-16 09:58:07 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 54
ERROR - 2021-06-16 09:58:07 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 62
ERROR - 2021-06-16 09:58:07 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 62
ERROR - 2021-06-16 09:58:07 --> Severity: Notice --> Trying to get property 'created_on' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 63
ERROR - 2021-06-16 09:58:07 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 84
ERROR - 2021-06-16 09:58:07 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 107
ERROR - 2021-06-16 09:58:07 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 107
ERROR - 2021-06-16 09:58:24 --> Could not find the language line "language"
ERROR - 2021-06-16 09:58:24 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 54
ERROR - 2021-06-16 09:58:24 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 54
ERROR - 2021-06-16 09:58:24 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 62
ERROR - 2021-06-16 09:58:24 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 62
ERROR - 2021-06-16 09:58:24 --> Severity: Notice --> Trying to get property 'created_on' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 63
ERROR - 2021-06-16 09:58:24 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 84
ERROR - 2021-06-16 09:58:24 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 107
ERROR - 2021-06-16 09:58:24 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 107
ERROR - 2021-06-16 09:59:00 --> Could not find the language line "language"
ERROR - 2021-06-16 09:59:00 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 54
ERROR - 2021-06-16 09:59:00 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 54
ERROR - 2021-06-16 09:59:00 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 62
ERROR - 2021-06-16 09:59:00 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 62
ERROR - 2021-06-16 09:59:00 --> Severity: Notice --> Trying to get property 'created_on' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 63
ERROR - 2021-06-16 09:59:00 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 84
ERROR - 2021-06-16 09:59:00 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 107
ERROR - 2021-06-16 09:59:00 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 107
ERROR - 2021-06-16 10:00:41 --> Could not find the language line "language"
ERROR - 2021-06-16 10:00:41 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 54
ERROR - 2021-06-16 10:00:41 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 54
ERROR - 2021-06-16 10:00:41 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 62
ERROR - 2021-06-16 10:00:41 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 62
ERROR - 2021-06-16 10:00:41 --> Severity: Notice --> Trying to get property 'created_on' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 63
ERROR - 2021-06-16 10:00:41 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 84
ERROR - 2021-06-16 10:00:41 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 107
ERROR - 2021-06-16 10:00:41 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 107
ERROR - 2021-06-16 10:00:47 --> Could not find the language line "language"
ERROR - 2021-06-16 10:00:47 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 54
ERROR - 2021-06-16 10:00:47 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 54
ERROR - 2021-06-16 10:00:47 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 62
ERROR - 2021-06-16 10:00:47 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 62
ERROR - 2021-06-16 10:00:47 --> Severity: Notice --> Trying to get property 'created_on' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 63
ERROR - 2021-06-16 10:00:47 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 84
ERROR - 2021-06-16 10:00:48 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 107
ERROR - 2021-06-16 10:00:48 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 107
ERROR - 2021-06-16 10:02:05 --> Could not find the language line "language"
ERROR - 2021-06-16 10:04:36 --> Could not find the language line "language"
ERROR - 2021-06-16 10:04:52 --> Could not find the language line "language"
ERROR - 2021-06-16 10:04:52 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 54
ERROR - 2021-06-16 10:04:52 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 54
ERROR - 2021-06-16 10:04:52 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 62
ERROR - 2021-06-16 10:04:52 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 62
ERROR - 2021-06-16 10:04:52 --> Severity: Notice --> Trying to get property 'created_on' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 63
ERROR - 2021-06-16 10:04:52 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 84
ERROR - 2021-06-16 10:04:52 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 107
ERROR - 2021-06-16 10:04:52 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 107
ERROR - 2021-06-16 10:05:47 --> Could not find the language line "language"
ERROR - 2021-06-16 10:05:47 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 54
ERROR - 2021-06-16 10:05:47 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 54
ERROR - 2021-06-16 10:05:47 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 62
ERROR - 2021-06-16 10:05:47 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 62
ERROR - 2021-06-16 10:05:47 --> Severity: Notice --> Trying to get property 'created_on' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 63
ERROR - 2021-06-16 10:05:47 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 84
ERROR - 2021-06-16 10:05:47 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 107
ERROR - 2021-06-16 10:05:47 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\template\navigation.php 107
ERROR - 2021-06-16 10:06:51 --> Could not find the language line "language"
ERROR - 2021-06-16 10:07:12 --> Could not find the language line "language"
ERROR - 2021-06-16 10:07:23 --> Could not find the language line "language"
ERROR - 2021-06-16 10:07:52 --> Could not find the language line "language"
ERROR - 2021-06-16 10:07:56 --> Could not find the language line "language"
ERROR - 2021-06-16 10:08:00 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 10:08:16 --> Could not find the language line "contacts"
ERROR - 2021-06-16 10:08:23 --> Could not find the language line "language"
ERROR - 2021-06-16 10:08:30 --> Could not find the language line "language"
ERROR - 2021-06-16 10:08:45 --> Could not find the language line "language"
ERROR - 2021-06-16 10:08:56 --> Could not find the language line "language"
ERROR - 2021-06-16 10:09:12 --> Could not find the language line "language"
ERROR - 2021-06-16 10:09:23 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 10:09:31 --> Could not find the language line "contacts"
ERROR - 2021-06-16 10:10:09 --> Could not find the language line "contacts"
ERROR - 2021-06-16 10:13:05 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 10:13:18 --> Could not find the language line "contacts"
ERROR - 2021-06-16 10:14:12 --> Could not find the language line "contacts"
ERROR - 2021-06-16 10:14:22 --> Could not find the language line "contacts"
ERROR - 2021-06-16 10:16:44 --> Could not find the language line "contacts"
ERROR - 2021-06-16 10:17:04 --> Could not find the language line "contacts"
ERROR - 2021-06-16 10:18:40 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 10:19:00 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 10:19:07 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 10:19:12 --> Could not find the language line "contacts"
ERROR - 2021-06-16 10:58:18 --> Could not find the language line "about"
ERROR - 2021-06-16 10:59:05 --> Could not find the language line "about"
ERROR - 2021-06-16 10:59:26 --> Could not find the language line "about"
ERROR - 2021-06-16 17:41:38 --> Could not find the language line "about"
ERROR - 2021-06-16 17:41:42 --> Could not find the language line "privacy_policy"
ERROR - 2021-06-16 21:45:32 --> Could not find the language line "contacts"
ERROR - 2021-06-16 21:45:41 --> Could not find the language line "privacy_policy"
ERROR - 2021-06-16 21:48:28 --> Could not find the language line "terms_of_service"
ERROR - 2021-06-16 21:48:48 --> Could not find the language line "terms_of_service"
ERROR - 2021-06-16 21:48:51 --> Could not find the language line "terms_of_service"
ERROR - 2021-06-16 21:48:53 --> Could not find the language line "privacy_policy"
ERROR - 2021-06-16 21:48:56 --> Could not find the language line "terms_of_service"
ERROR - 2021-06-16 21:49:33 --> Could not find the language line "terms_of_service"
ERROR - 2021-06-16 21:49:48 --> Could not find the language line "contacts"
ERROR - 2021-06-16 21:53:34 --> Could not find the language line "about"
ERROR - 2021-06-16 21:53:38 --> Could not find the language line "donate_book"
ERROR - 2021-06-16 21:53:57 --> Could not find the language line "donate_book"
ERROR - 2021-06-16 21:54:14 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 21:54:18 --> Could not find the language line "donate_book"
ERROR - 2021-06-16 21:55:39 --> Could not find the language line "donate_book"
ERROR - 2021-06-16 21:56:08 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 21:56:12 --> Could not find the language line "Faqs"
ERROR - 2021-06-16 21:56:16 --> Could not find the language line "about"
ERROR - 2021-06-16 21:56:18 --> Could not find the language line "contacts"
ERROR - 2021-06-16 21:56:21 --> Could not find the language line "donate_book"
ERROR - 2021-06-16 21:56:23 --> Could not find the language line "Faqs"
ERROR - 2021-06-16 21:56:25 --> Could not find the language line "about"
ERROR - 2021-06-16 21:56:28 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 21:59:19 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 21:59:26 --> Could not find the language line "donate_book"
ERROR - 2021-06-16 22:01:51 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 22:01:56 --> Could not find the language line "book_plan"
ERROR - 2021-06-16 22:01:59 --> Could not find the language line "donate_book"
ERROR - 2021-06-16 22:02:02 --> Could not find the language line "Faqs"
ERROR - 2021-06-16 22:02:04 --> Could not find the language line "about"
ERROR - 2021-06-16 22:02:06 --> Could not find the language line "contacts"
ERROR - 2021-06-16 22:28:48 --> Could not find the language line "book_plan"
ERROR - 2021-06-16 22:29:40 --> Could not find the language line "book_total_label"
ERROR - 2021-06-16 22:30:27 --> Could not find the language line "book_plan"
ERROR - 2021-06-16 22:36:43 --> Could not find the language line "donate_book"
ERROR - 2021-06-16 22:39:09 --> Could not find the language line "donate_book"
ERROR - 2021-06-16 22:39:12 --> Could not find the language line "book_plan"
ERROR - 2021-06-16 22:39:15 --> Could not find the language line "donate_book"
ERROR - 2021-06-16 22:39:17 --> Could not find the language line "Faqs"
ERROR - 2021-06-16 22:39:20 --> Could not find the language line "about"
ERROR - 2021-06-16 22:39:22 --> Could not find the language line "contacts"
