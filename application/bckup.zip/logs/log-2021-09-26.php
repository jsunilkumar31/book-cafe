<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-26 00:07:43 --> Could not find the language line "book_plan"
ERROR - 2021-09-26 00:07:43 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 17
ERROR - 2021-09-26 00:07:43 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 18
ERROR - 2021-09-26 00:07:43 --> Severity: Notice --> Trying to get property 'book_title' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 38
ERROR - 2021-09-26 00:07:43 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 41
ERROR - 2021-09-26 00:07:43 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 42
ERROR - 2021-09-26 00:07:43 --> Severity: Notice --> Trying to get property 'description' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 54
ERROR - 2021-09-26 00:07:43 --> Severity: Notice --> Trying to get property 'author_name' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 57
ERROR - 2021-09-26 00:42:51 --> Could not find the language line "book_plan"
ERROR - 2021-09-26 01:09:43 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 01:54:43 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 01:56:36 --> Could not find the language line "book_plan"
ERROR - 2021-09-26 02:09:31 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 03:00:21 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 03:10:46 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 03:24:43 --> Could not find the language line "terms_of_service"
ERROR - 2021-09-26 03:39:38 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 04:22:03 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 04:55:45 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 05:25:20 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 05:53:33 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 06:13:30 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 06:22:20 --> Could not find the language line "book_plan"
ERROR - 2021-09-26 06:24:43 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 06:27:07 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 06:58:29 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 07:36:36 --> Could not find the language line "donate_book"
ERROR - 2021-09-26 07:45:26 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 07:50:06 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 08:05:36 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 08:26:24 --> Could not find the language line "donate_book"
ERROR - 2021-09-26 08:41:26 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 10:06:55 --> Could not find the language line "book_plan"
ERROR - 2021-09-26 11:45:31 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 12:20:25 --> Could not find the language line "donate_book"
ERROR - 2021-09-26 12:38:29 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 12:47:40 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 13:05:25 --> Could not find the language line "book_plan"
ERROR - 2021-09-26 13:44:21 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 13:44:30 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 13:44:40 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 13:45:20 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 13:50:25 --> Could not find the language line "privacy_policy"
ERROR - 2021-09-26 14:35:25 --> Could not find the language line "book_plan"
ERROR - 2021-09-26 14:35:25 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 17
ERROR - 2021-09-26 14:35:25 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 18
ERROR - 2021-09-26 14:35:25 --> Severity: Notice --> Trying to get property 'book_title' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 38
ERROR - 2021-09-26 14:35:25 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 41
ERROR - 2021-09-26 14:35:25 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 42
ERROR - 2021-09-26 14:35:25 --> Severity: Notice --> Trying to get property 'description' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 54
ERROR - 2021-09-26 14:35:25 --> Severity: Notice --> Trying to get property 'author_name' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 57
ERROR - 2021-09-26 15:24:43 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 15:47:13 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 15:47:13 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 18:07:37 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 18:20:07 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 18:20:43 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 18:21:58 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 18:22:48 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 18:24:01 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 19:04:34 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 19:10:33 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 19:20:06 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 20:11:35 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 21:00:07 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 21:28:29 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 22:17:35 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 23:02:35 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 23:21:00 --> Could not find the language line "book_total_label"
ERROR - 2021-09-26 23:47:35 --> Could not find the language line "book_total_label"
