<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-27 21:37:29 --> Could not find the language line "book_total_label"
ERROR - 2021-06-27 22:14:39 --> Could not find the language line "book_total_label"
ERROR - 2021-06-27 22:35:44 --> Could not find the language line "Faqs"
ERROR - 2021-06-27 22:39:24 --> Could not find the language line "Faqs"
ERROR - 2021-06-27 22:39:53 --> Could not find the language line "Faqs"
ERROR - 2021-06-27 22:41:53 --> Could not find the language line "Faqs"
ERROR - 2021-06-27 22:45:50 --> Could not find the language line "Faqs"
ERROR - 2021-06-27 22:54:34 --> Could not find the language line "Faqs"
ERROR - 2021-06-27 22:56:56 --> Could not find the language line "Faqs"
ERROR - 2021-06-27 23:08:41 --> Could not find the language line "contacts"
ERROR - 2021-06-27 23:09:13 --> Could not find the language line "contacts"
ERROR - 2021-06-27 23:09:16 --> Could not find the language line "Faqs"
