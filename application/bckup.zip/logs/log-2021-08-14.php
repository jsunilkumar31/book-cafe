<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-14 00:03:25 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 00:18:12 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 00:43:19 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 01:18:12 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 01:23:39 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 05:33:24 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 06:15:36 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 08:11:54 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 08:11:54 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 17
ERROR - 2021-08-14 08:11:54 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 18
ERROR - 2021-08-14 08:11:54 --> Severity: Notice --> Trying to get property 'book_title' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 38
ERROR - 2021-08-14 08:11:54 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 41
ERROR - 2021-08-14 08:11:54 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 42
ERROR - 2021-08-14 08:11:54 --> Severity: Notice --> Trying to get property 'description' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 54
ERROR - 2021-08-14 08:11:54 --> Severity: Notice --> Trying to get property 'author_name' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 57
ERROR - 2021-08-14 08:41:55 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 08:49:04 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 09:04:13 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 09:56:01 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 10:18:52 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 10:48:13 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 11:18:13 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 11:48:13 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 11:56:49 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 12:05:28 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 12:05:28 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 17
ERROR - 2021-08-14 12:05:28 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 18
ERROR - 2021-08-14 12:05:28 --> Severity: Notice --> Trying to get property 'book_title' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 38
ERROR - 2021-08-14 12:05:28 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 41
ERROR - 2021-08-14 12:05:28 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 42
ERROR - 2021-08-14 12:05:28 --> Severity: Notice --> Trying to get property 'description' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 54
ERROR - 2021-08-14 12:05:28 --> Severity: Notice --> Trying to get property 'author_name' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 57
ERROR - 2021-08-14 12:18:13 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 12:20:28 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 12:35:28 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 12:35:28 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 17
ERROR - 2021-08-14 12:35:28 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 18
ERROR - 2021-08-14 12:35:28 --> Severity: Notice --> Trying to get property 'book_title' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 38
ERROR - 2021-08-14 12:35:28 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 41
ERROR - 2021-08-14 12:35:28 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 42
ERROR - 2021-08-14 12:35:28 --> Severity: Notice --> Trying to get property 'description' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 54
ERROR - 2021-08-14 12:35:28 --> Severity: Notice --> Trying to get property 'author_name' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 57
ERROR - 2021-08-14 12:48:14 --> Could not find the language line "privacy_policy"
ERROR - 2021-08-14 13:18:13 --> Could not find the language line "privacy_policy"
ERROR - 2021-08-14 13:52:20 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 13:52:58 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 14:02:43 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 14:07:01 --> Could not find the language line "donate_book"
ERROR - 2021-08-14 14:21:48 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 14:22:23 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 16:28:51 --> Could not find the language line "donate_book"
ERROR - 2021-08-14 19:58:11 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 20:40:53 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 20:45:16 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 21:08:31 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 21:15:16 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 21:25:00 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 21:40:56 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 21:45:15 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 21:52:15 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 21:55:00 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 22:15:16 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 22:25:01 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 22:40:53 --> Could not find the language line "book_total_label"
ERROR - 2021-08-14 22:41:14 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 22:45:16 --> Could not find the language line "privacy_policy"
ERROR - 2021-08-14 23:06:45 --> Could not find the language line "book_plan"
ERROR - 2021-08-14 23:15:16 --> Could not find the language line "privacy_policy"
ERROR - 2021-08-14 23:55:01 --> Could not find the language line "book_plan"
