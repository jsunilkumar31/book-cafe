ERROR - 2021-06-15 23:00:16 --> Could not find the language line "contacts"
ERROR - 2021-06-15 23:00:16 --> Severity: Notice --> Undefined variable: category_id C:\xampp\htdocs\bookscafe-ci\application\controllers\Contact.php 26
ERROR - 2021-06-15 23:00:16 --> Severity: Notice --> Undefined variable: author_id C:\xampp\htdocs\bookscafe-ci\application\controllers\Contact.php 26
ERROR - 2021-06-15 23:00:16 --> Severity: Notice --> Undefined variable: book_title C:\xampp\htdocs\bookscafe-ci\application\controllers\Contact.php 26
ERROR - 2021-06-15 23:00:38 --> Could not find the language line "contacts"
