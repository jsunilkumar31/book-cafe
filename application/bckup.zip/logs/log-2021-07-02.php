<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-02 11:37:07 --> Could not find the language line "book_total_label"
ERROR - 2021-07-02 11:40:09 --> Could not find the language line "language"
ERROR - 2021-07-02 11:40:16 --> Could not find the language line "language"
ERROR - 2021-07-02 11:40:19 --> Could not find the language line "language"
ERROR - 2021-07-02 11:40:39 --> Severity: Notice --> Undefined index: publisher C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\controllers\Books.php 675
ERROR - 2021-07-02 11:40:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'preferences')' at line 1 - Invalid query: INSERT IGNORE INTO `categories`(`category_name`) VALUES ('Consumers' preferences')
ERROR - 2021-07-02 11:55:09 --> Severity: Notice --> Undefined index: publisher C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\controllers\Books.php 666
ERROR - 2021-07-02 11:59:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'preferences')' at line 1 - Invalid query: INSERT IGNORE INTO `categories`(`category_name`) VALUES ('Consumers' preferences')
ERROR - 2021-07-02 12:08:10 --> Could not find the language line "language"
ERROR - 2021-07-02 12:08:11 --> Severity: Notice --> Undefined index: custom_fields C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 114
ERROR - 2021-07-02 12:11:52 --> Could not find the language line "language"
ERROR - 2021-07-02 12:11:52 --> Severity: Notice --> Undefined index: isbn C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 31
ERROR - 2021-07-02 12:11:52 --> Severity: Notice --> Undefined index: book_title C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 36
ERROR - 2021-07-02 12:11:52 --> Severity: Notice --> Undefined index: category_name C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 43
ERROR - 2021-07-02 12:11:52 --> Severity: Notice --> Undefined index: author_name C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 56
ERROR - 2021-07-02 12:11:52 --> Severity: Notice --> Undefined index: custom_fields C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 114
ERROR - 2021-07-02 12:12:08 --> Could not find the language line "language"
ERROR - 2021-07-02 12:12:13 --> Could not find the language line "language"
ERROR - 2021-07-02 12:12:13 --> Severity: Notice --> Undefined index: isbn C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 31
ERROR - 2021-07-02 12:12:13 --> Severity: Notice --> Undefined index: book_title C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 36
ERROR - 2021-07-02 12:12:13 --> Severity: Notice --> Undefined index: category_name C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 43
ERROR - 2021-07-02 12:12:13 --> Severity: Notice --> Undefined index: author_name C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 56
ERROR - 2021-07-02 12:12:13 --> Severity: Notice --> Undefined index: custom_fields C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 114
ERROR - 2021-07-02 12:13:13 --> Could not find the language line "language"
ERROR - 2021-07-02 12:13:13 --> Severity: Notice --> Undefined index: isbn C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 31
ERROR - 2021-07-02 12:13:13 --> Severity: Notice --> Undefined index: book_title C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 36
ERROR - 2021-07-02 12:13:13 --> Severity: Notice --> Undefined index: category_name C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 43
ERROR - 2021-07-02 12:13:13 --> Severity: Notice --> Undefined index: author_name C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 56
ERROR - 2021-07-02 12:13:13 --> Severity: Notice --> Undefined index: custom_fields C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 114
ERROR - 2021-07-02 12:15:18 --> Could not find the language line "language"
ERROR - 2021-07-02 12:15:18 --> Severity: Notice --> Undefined index: isbn C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 31
ERROR - 2021-07-02 12:15:18 --> Severity: Notice --> Undefined index: book_title C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 36
ERROR - 2021-07-02 12:15:18 --> Severity: Notice --> Undefined index: category_name C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 43
ERROR - 2021-07-02 12:15:18 --> Severity: Notice --> Undefined index: author_name C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 56
ERROR - 2021-07-02 12:15:18 --> Severity: Notice --> Undefined index: custom_fields C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 114
ERROR - 2021-07-02 12:15:54 --> Could not find the language line "language"
ERROR - 2021-07-02 12:16:15 --> Could not find the language line "language"
ERROR - 2021-07-02 12:17:37 --> Could not find the language line "language"
ERROR - 2021-07-02 12:17:37 --> Severity: Notice --> Undefined index: isbn C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 32
ERROR - 2021-07-02 12:17:37 --> Severity: Notice --> Undefined index: book_title C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 37
ERROR - 2021-07-02 12:17:37 --> Severity: Notice --> Undefined index: category_name C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 44
ERROR - 2021-07-02 12:17:37 --> Severity: Notice --> Undefined index: author_name C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 57
ERROR - 2021-07-02 12:17:37 --> Severity: Notice --> Undefined index: custom_fields C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 115
ERROR - 2021-07-02 12:18:11 --> Could not find the language line "language"
ERROR - 2021-07-02 12:18:11 --> Severity: Notice --> Undefined index: isbn C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 32
ERROR - 2021-07-02 12:18:11 --> Severity: Notice --> Undefined index: book_title C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 37
ERROR - 2021-07-02 12:18:11 --> Severity: Notice --> Undefined index: category_name C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 44
ERROR - 2021-07-02 12:18:11 --> Severity: Notice --> Undefined index: author_name C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 57
ERROR - 2021-07-02 12:18:11 --> Severity: Notice --> Undefined index: custom_fields C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 115
ERROR - 2021-07-02 12:18:56 --> Could not find the language line "language"
ERROR - 2021-07-02 12:18:56 --> Severity: Notice --> Undefined index: isbn C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 32
ERROR - 2021-07-02 12:18:56 --> Severity: Notice --> Undefined index: book_title C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 37
ERROR - 2021-07-02 12:18:56 --> Severity: Notice --> Undefined index: category_name C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 44
ERROR - 2021-07-02 12:18:56 --> Severity: Notice --> Undefined index: author_name C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 57
ERROR - 2021-07-02 12:18:56 --> Severity: Notice --> Undefined index: custom_fields C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 115
ERROR - 2021-07-02 12:21:21 --> Could not find the language line "language"
ERROR - 2021-07-02 12:21:21 --> Severity: Notice --> Undefined index: category_name C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 55
ERROR - 2021-07-02 12:21:21 --> Severity: Notice --> Undefined index: author_name C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 68
ERROR - 2021-07-02 12:21:21 --> Severity: Notice --> Undefined index: custom_fields C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 126
ERROR - 2021-07-02 12:21:35 --> Could not find the language line "language"
ERROR - 2021-07-02 12:21:35 --> Severity: Notice --> Undefined index: custom_fields C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 126
ERROR - 2021-07-02 12:23:18 --> Severity: Notice --> Undefined index: categories C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\controllers\Books.php 689
ERROR - 2021-07-02 12:23:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\controllers\Books.php 689
ERROR - 2021-07-02 12:23:18 --> Could not find the language line "language"
ERROR - 2021-07-02 12:23:18 --> Severity: Notice --> Undefined index: custom_fields C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 126
ERROR - 2021-07-02 12:30:31 --> Could not find the language line "language"
ERROR - 2021-07-02 12:30:31 --> Severity: Notice --> Undefined index: custom_fields C:\xampp\htdocs\bookscafe-ci_old\application\modules\panel\views\books\edit.php 126
