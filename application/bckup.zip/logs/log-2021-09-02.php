<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-02 05:00:43 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 05:55:48 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 06:55:48 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 07:55:48 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 10:57:50 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 10:58:00 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 10:59:58 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 11:00:08 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 11:30:43 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 12:00:42 --> Could not find the language line "about"
ERROR - 2021-09-02 13:48:06 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 13:48:42 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 13:48:52 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 13:49:04 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 13:52:38 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 13:52:40 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 13:54:06 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 13:55:26 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 13:55:47 --> Could not find the language line "about"
ERROR - 2021-09-02 13:55:52 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 14:01:33 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 14:02:43 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 14:03:23 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 14:08:25 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 14:55:48 --> Could not find the language line "book_plan"
ERROR - 2021-09-02 14:55:48 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 17
ERROR - 2021-09-02 14:55:48 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 18
ERROR - 2021-09-02 14:55:48 --> Severity: Notice --> Trying to get property 'book_title' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 38
ERROR - 2021-09-02 14:55:48 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 41
ERROR - 2021-09-02 14:55:48 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 42
ERROR - 2021-09-02 14:55:48 --> Severity: Notice --> Trying to get property 'description' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 54
ERROR - 2021-09-02 14:55:48 --> Severity: Notice --> Trying to get property 'author_name' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 57
ERROR - 2021-09-02 15:39:42 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 15:41:17 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 23:28:27 --> Could not find the language line "book_total_label"
ERROR - 2021-09-02 23:36:50 --> Could not find the language line "about"
