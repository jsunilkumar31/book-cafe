<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-03 00:36:52 --> Could not find the language line "about"
ERROR - 2021-09-03 01:06:52 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 01:36:52 --> Could not find the language line "book_plan"
ERROR - 2021-09-03 02:02:26 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 02:06:52 --> Could not find the language line "book_plan"
ERROR - 2021-09-03 02:06:52 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 17
ERROR - 2021-09-03 02:06:52 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 18
ERROR - 2021-09-03 02:06:52 --> Severity: Notice --> Trying to get property 'book_title' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 38
ERROR - 2021-09-03 02:06:52 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 41
ERROR - 2021-09-03 02:06:52 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 42
ERROR - 2021-09-03 02:06:52 --> Severity: Notice --> Trying to get property 'description' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 54
ERROR - 2021-09-03 02:06:52 --> Severity: Notice --> Trying to get property 'author_name' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 57
ERROR - 2021-09-03 02:58:54 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 03:06:50 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 04:06:50 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 04:07:58 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 05:06:58 --> Could not find the language line "book_plan"
ERROR - 2021-09-03 05:06:58 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 17
ERROR - 2021-09-03 05:06:58 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 18
ERROR - 2021-09-03 05:06:58 --> Severity: Notice --> Trying to get property 'book_title' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 38
ERROR - 2021-09-03 05:06:58 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 41
ERROR - 2021-09-03 05:06:58 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 42
ERROR - 2021-09-03 05:06:58 --> Severity: Notice --> Trying to get property 'description' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 54
ERROR - 2021-09-03 05:06:58 --> Severity: Notice --> Trying to get property 'author_name' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 57
ERROR - 2021-09-03 06:06:50 --> Could not find the language line "book_plan"
ERROR - 2021-09-03 06:06:50 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 17
ERROR - 2021-09-03 06:06:50 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 18
ERROR - 2021-09-03 06:06:50 --> Severity: Notice --> Trying to get property 'book_title' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 38
ERROR - 2021-09-03 06:06:50 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 41
ERROR - 2021-09-03 06:06:50 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 42
ERROR - 2021-09-03 06:06:50 --> Severity: Notice --> Trying to get property 'description' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 54
ERROR - 2021-09-03 06:06:50 --> Severity: Notice --> Trying to get property 'author_name' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 57
ERROR - 2021-09-03 07:06:50 --> Could not find the language line "book_plan"
ERROR - 2021-09-03 08:06:50 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 11:59:19 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 12:00:08 --> Could not find the language line "book_plan"
ERROR - 2021-09-03 14:04:02 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 14:04:22 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 14:04:43 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 14:05:15 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 14:05:32 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 14:11:07 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 16:26:00 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 17:31:50 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 17:52:28 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 20:08:49 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 20:21:00 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 20:21:14 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 20:29:20 --> Could not find the language line "privacy_policy"
ERROR - 2021-09-03 20:29:29 --> Could not find the language line "privacy_policy"
ERROR - 2021-09-03 20:29:34 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 20:29:41 --> Could not find the language line "privacy_policy"
ERROR - 2021-09-03 20:29:48 --> Could not find the language line "terms_of_service"
ERROR - 2021-09-03 20:30:02 --> Could not find the language line "terms_of_service"
ERROR - 2021-09-03 20:30:05 --> Could not find the language line "privacy_policy"
ERROR - 2021-09-03 20:30:42 --> Could not find the language line "about"
ERROR - 2021-09-03 20:31:04 --> Could not find the language line "contacts"
ERROR - 2021-09-03 20:31:14 --> Could not find the language line "contacts"
ERROR - 2021-09-03 20:31:17 --> Could not find the language line "Faqs"
ERROR - 2021-09-03 20:31:24 --> Could not find the language line "book_plan"
ERROR - 2021-09-03 20:50:58 --> Could not find the language line "terms_of_service"
ERROR - 2021-09-03 20:51:07 --> Could not find the language line "privacy_policy"
ERROR - 2021-09-03 20:52:15 --> Could not find the language line "privacy_policy"
ERROR - 2021-09-03 20:52:20 --> Could not find the language line "privacy_policy"
ERROR - 2021-09-03 20:54:18 --> Could not find the language line "privacy_policy"
ERROR - 2021-09-03 20:58:05 --> Could not find the language line "privacy_policy"
ERROR - 2021-09-03 20:58:53 --> Could not find the language line "privacy_policy"
ERROR - 2021-09-03 20:59:20 --> Could not find the language line "privacy_policy"
ERROR - 2021-09-03 20:59:54 --> Could not find the language line "about"
ERROR - 2021-09-03 21:07:26 --> Could not find the language line "about"
ERROR - 2021-09-03 22:02:20 --> Could not find the language line "book_plan"
ERROR - 2021-09-03 22:17:25 --> Could not find the language line "book_plan"
ERROR - 2021-09-03 22:17:30 --> Could not find the language line "about"
ERROR - 2021-09-03 22:22:56 --> Could not find the language line "book_total_label"
ERROR - 2021-09-03 23:33:18 --> Could not find the language line "about"
ERROR - 2021-09-03 23:33:59 --> Could not find the language line "about"
ERROR - 2021-09-03 23:34:29 --> Could not find the language line "about"
ERROR - 2021-09-03 23:35:01 --> Could not find the language line "about"
ERROR - 2021-09-03 23:35:37 --> Could not find the language line "about"
ERROR - 2021-09-03 23:36:18 --> Could not find the language line "about"
ERROR - 2021-09-03 23:36:58 --> Could not find the language line "about"
ERROR - 2021-09-03 23:40:40 --> Could not find the language line "about"
ERROR - 2021-09-03 23:41:47 --> Could not find the language line "about"
ERROR - 2021-09-03 23:42:55 --> Could not find the language line "about"
ERROR - 2021-09-03 23:43:24 --> Could not find the language line "about"
ERROR - 2021-09-03 23:46:39 --> Could not find the language line "about"
ERROR - 2021-09-03 23:47:00 --> Could not find the language line "about"
