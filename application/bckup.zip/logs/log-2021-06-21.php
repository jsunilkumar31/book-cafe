<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-21 21:37:13 --> Could not find the language line "book_total_label"
ERROR - 2021-06-21 21:44:42 --> Could not find the language line "donate_book"
ERROR - 2021-06-21 21:46:30 --> Could not find the language line "donate_book"
ERROR - 2021-06-21 21:48:39 --> Could not find the language line "donate_book"
ERROR - 2021-06-21 21:49:41 --> Could not find the language line "donate_book"
ERROR - 2021-06-21 21:53:39 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 21:57:45 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 21:58:02 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 21:58:18 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 21:58:54 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:02:26 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:03:00 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:03:41 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:04:03 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:05:58 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:07:20 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:09:00 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:15:11 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:15:37 --> Could not find the language line "contacts"
ERROR - 2021-06-21 22:17:12 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:17:25 --> Could not find the language line "contacts"
ERROR - 2021-06-21 22:17:39 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:17:44 --> Could not find the language line "contacts"
ERROR - 2021-06-21 22:17:47 --> Could not find the language line "donate_book"
ERROR - 2021-06-21 22:17:49 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:26:50 --> Could not find the language line "language"
ERROR - 2021-06-21 22:26:56 --> Could not find the language line "language"
ERROR - 2021-06-21 22:27:08 --> Could not find the language line "language"
ERROR - 2021-06-21 22:27:47 --> Could not find the language line "donate_book"
ERROR - 2021-06-21 22:28:00 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:28:07 --> Could not find the language line "donate_book"
ERROR - 2021-06-21 22:28:12 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:28:19 --> Could not find the language line "donate_book"
ERROR - 2021-06-21 22:29:46 --> Could not find the language line "donate_book"
ERROR - 2021-06-21 22:33:53 --> Could not find the language line "donate_book"
ERROR - 2021-06-21 22:34:28 --> Could not find the language line "book_total_label"
ERROR - 2021-06-21 22:38:37 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:38:57 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:39:21 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:41:04 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:42:02 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:43:02 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:43:13 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:44:30 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:54:11 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 22:54:25 --> Could not find the language line "book_total_label"
ERROR - 2021-06-21 22:57:46 --> Could not find the language line "book_total_label"
ERROR - 2021-06-21 23:00:02 --> Could not find the language line "book_total_label"
ERROR - 2021-06-21 23:00:14 --> Could not find the language line "book_total_label"
ERROR - 2021-06-21 23:03:13 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:03:13 --> Severity: error --> Exception: Too few arguments to function CI_URI::segment(), 0 passed in C:\xampp\htdocs\bookscafe-ci_old\application\controllers\Books.php on line 58 and at least 1 expected C:\xampp\htdocs\bookscafe-ci_old\system\core\URI.php 344
ERROR - 2021-06-21 23:03:33 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:03:50 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:07:45 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:07:54 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:08:02 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:08:08 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:08:24 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:08:29 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:08:30 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:08:32 --> Could not find the language line "book_total_label"
ERROR - 2021-06-21 23:08:32 --> Could not find the language line "book_total_label"
ERROR - 2021-06-21 23:08:41 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:13:25 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:14:20 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:14:20 --> Severity: error --> Exception: syntax error, unexpected ''</pre>' (T_ENCAPSED_AND_WHITESPACE) C:\xampp\htdocs\bookscafe-ci_old\application\views\book-single.php 105
ERROR - 2021-06-21 23:14:45 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:19:25 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:19:25 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT *, GROUP_CONCAT(authors.author_name SEPARATOR ", ") as authors
FROM `books`
LEFT JOIN `book_categories` ON `books`.`id`=`book_categories`.`book_id`
LEFT JOIN `book_authors` ON `books`.`id`=`book_authors`.`book_id`
LEFT JOIN `authors` ON `authors`.`id`=`book_authors`.`author_id`
WHERE `id` = '4'
GROUP BY `books`.`id`
 LIMIT 1
ERROR - 2021-06-21 23:19:45 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:19:45 --> Severity: Notice --> Undefined property: stdClass::$author C:\xampp\htdocs\bookscafe-ci_old\application\views\book-single.php 126
ERROR - 2021-06-21 23:21:29 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:21:42 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:22:09 --> Could not find the language line "language"
ERROR - 2021-06-21 23:22:14 --> Could not find the language line "book_total_label"
ERROR - 2021-06-21 23:27:12 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:27:27 --> Could not find the language line "book_total_label"
ERROR - 2021-06-21 23:27:46 --> Could not find the language line "book_total_label"
ERROR - 2021-06-21 23:27:52 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:27:57 --> Could not find the language line "book_total_label"
ERROR - 2021-06-21 23:28:25 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:29:07 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:30:38 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:31:03 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:31:03 --> Severity: Notice --> Undefined property: stdClass::$author_name C:\xampp\htdocs\bookscafe-ci_old\application\views\book-single.php 62
ERROR - 2021-06-21 23:31:20 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:31:20 --> Severity: Notice --> Undefined property: stdClass::$author_name C:\xampp\htdocs\bookscafe-ci_old\application\views\book-single.php 62
ERROR - 2021-06-21 23:31:27 --> Could not find the language line "book_total_label"
ERROR - 2021-06-21 23:33:41 --> Could not find the language line "book_total_label"
ERROR - 2021-06-21 23:34:54 --> Could not find the language line "book_total_label"
ERROR - 2021-06-21 23:35:00 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:35:00 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT *, GROUP_CONCAT(authors.author_name SEPARATOR ", ") as authors
FROM `books`
LEFT JOIN `book_categories` ON `books`.`id`=`book_categories`.`book_id`
LEFT JOIN `book_authors` ON `books`.`id`=`book_authors`.`book_id`
LEFT JOIN `authors` ON `authors`.`id`=`book_authors`.`author_id`
WHERE `id` = '2'
GROUP BY `books`.`id`
 LIMIT 1
ERROR - 2021-06-21 23:35:14 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:35:30 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:36:11 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:36:22 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:36:30 --> Could not find the language line "book_total_label"
ERROR - 2021-06-21 23:36:35 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:36:41 --> Could not find the language line "book_total_label"
ERROR - 2021-06-21 23:37:01 --> Could not find the language line "book_plan"
ERROR - 2021-06-21 23:37:08 --> Could not find the language line "book_total_label"
