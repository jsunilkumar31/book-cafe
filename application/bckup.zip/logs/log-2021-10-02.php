<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-02 06:08:25 --> Could not find the language line "book_total_label"
ERROR - 2021-10-02 06:08:33 --> Could not find the language line "book_plan"
ERROR - 2021-10-02 06:08:34 --> Could not find the language line "book_plan"
ERROR - 2021-10-02 06:08:34 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 17
ERROR - 2021-10-02 06:08:34 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 18
ERROR - 2021-10-02 06:08:34 --> Severity: Notice --> Trying to get property 'book_title' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 38
ERROR - 2021-10-02 06:08:34 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 41
ERROR - 2021-10-02 06:08:34 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 42
ERROR - 2021-10-02 06:08:34 --> Severity: Notice --> Trying to get property 'description' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 54
ERROR - 2021-10-02 06:08:34 --> Severity: Notice --> Trying to get property 'author_name' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 57
ERROR - 2021-10-02 07:32:21 --> Could not find the language line "book_total_label"
ERROR - 2021-10-02 08:25:45 --> Could not find the language line "book_total_label"
ERROR - 2021-10-02 13:33:20 --> Could not find the language line "book_total_label"
ERROR - 2021-10-02 13:33:31 --> Could not find the language line "book_total_label"
ERROR - 2021-10-02 13:35:08 --> Could not find the language line "book_total_label"
ERROR - 2021-10-02 13:40:51 --> Could not find the language line "book_total_label"
ERROR - 2021-10-02 13:46:22 --> Could not find the language line "book_total_label"
ERROR - 2021-10-02 13:50:25 --> Could not find the language line "book_total_label"
ERROR - 2021-10-02 13:50:31 --> Could not find the language line "book_total_label"
ERROR - 2021-10-02 13:50:58 --> Could not find the language line "book_total_label"
ERROR - 2021-10-02 13:52:00 --> Could not find the language line "book_total_label"
ERROR - 2021-10-02 14:23:36 --> Could not find the language line "contacts"
ERROR - 2021-10-02 17:47:09 --> Could not find the language line "book_total_label"
ERROR - 2021-10-02 18:07:37 --> Could not find the language line "book_total_label"
ERROR - 2021-10-02 20:30:07 --> Could not find the language line "book_total_label"
ERROR - 2021-10-02 22:58:14 --> Could not find the language line "book_total_label"
ERROR - 2021-10-02 23:21:50 --> Could not find the language line "book_total_label"
