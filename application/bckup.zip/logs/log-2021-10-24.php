<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-24 02:26:56 --> Could not find the language line "contacts"
ERROR - 2021-10-24 03:25:58 --> Could not find the language line "book_total_label"
ERROR - 2021-10-24 04:10:58 --> Could not find the language line "book_total_label"
ERROR - 2021-10-24 04:51:11 --> Could not find the language line "book_plan"
ERROR - 2021-10-24 05:07:04 --> Could not find the language line "book_total_label"
ERROR - 2021-10-24 05:07:05 --> Could not find the language line "book_total_label"
ERROR - 2021-10-24 05:07:05 --> Could not find the language line "book_total_label"
ERROR - 2021-10-24 05:14:38 --> Could not find the language line "book_plan"
ERROR - 2021-10-24 05:14:38 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 17
ERROR - 2021-10-24 05:14:38 --> Severity: Notice --> Trying to get property 'image' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 18
ERROR - 2021-10-24 05:14:38 --> Severity: Notice --> Trying to get property 'book_title' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 38
ERROR - 2021-10-24 05:14:38 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 41
ERROR - 2021-10-24 05:14:38 --> Severity: Notice --> Trying to get property 'price' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 42
ERROR - 2021-10-24 05:14:38 --> Severity: Notice --> Trying to get property 'description' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 54
ERROR - 2021-10-24 05:14:38 --> Severity: Notice --> Trying to get property 'author_name' of non-object /home/u614250440/domains/bookscafe.co.in/public_html/application/views/book-single.php 57
ERROR - 2021-10-24 06:31:42 --> Could not find the language line "book_plan"
ERROR - 2021-10-24 06:44:51 --> Could not find the language line "terms_of_service"
ERROR - 2021-10-24 07:13:13 --> Could not find the language line "book_total_label"
ERROR - 2021-10-24 07:13:19 --> Could not find the language line "book_total_label"
ERROR - 2021-10-24 08:12:18 --> Could not find the language line "book_total_label"
ERROR - 2021-10-24 08:14:00 --> Could not find the language line "book_plan"
ERROR - 2021-10-24 09:25:56 --> Could not find the language line "book_total_label"
ERROR - 2021-10-24 09:25:59 --> Could not find the language line "book_total_label"
ERROR - 2021-10-24 09:43:11 --> Could not find the language line "privacy_policy"
ERROR - 2021-10-24 10:56:34 --> Could not find the language line "book_total_label"
ERROR - 2021-10-24 11:11:58 --> Could not find the language line "Faqs"
ERROR - 2021-10-24 11:22:23 --> Could not find the language line "book_total_label"
ERROR - 2021-10-24 11:22:24 --> Could not find the language line "book_total_label"
ERROR - 2021-10-24 11:22:26 --> Could not find the language line "book_total_label"
ERROR - 2021-10-24 11:23:12 --> Could not find the language line "contacts"
ERROR - 2021-10-24 11:33:10 --> Could not find the language line "book_total_label"
ERROR - 2021-10-24 11:33:14 --> Could not find the language line "book_total_label"
ERROR - 2021-10-24 11:33:43 --> Could not find the language line "book_total_label"
ERROR - 2021-10-24 11:33:49 --> Could not find the language line "book_plan"
