 <!-- Page Content -->
<div class="container">
    <div class="row">
      <iframe src="<?= base_url();?>pdf/web/viewer.html?file=<?= base_url(); ?>files/<?= $book->digital_file; ?>" width="100%" height="600px" />
    </div>
    <!-- /.row -->
</div>
<!-- /.container -->