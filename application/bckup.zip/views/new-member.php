<div id="content-page" class="content-page">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="iq-card">
                    <div class="iq-card-body">

                        <section class="py-5">
                            <h5 class="mb-5 text-center">New Member Registration</h5>
                            <div class="container">
                                <div class="row">
                                    
                                    <div class="embed-responsive embed-responsive-16by9">
                                                
                                                <iframe class="embed-responsive-item"
                                                    src="https://docs.google.com/forms/d/e/1FAIpQLSceDubvpdgT9uhXe_kkHWHvlEo4FqBwqbi40E7kH0mmry0qEg/viewform?embedded=true"
                                                    allowfullscreen frameborder="0" marginheight="0"></iframe>
                                            </div>
                                            
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>