<div id="content-page" class="content-page">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="iq-card">
                    <div class="iq-card-body">
                       
                        <section class="py-5">
                            <h2 class="mb-5 text-center">Privacy Policy</h2>
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-6 mb-3 mb-md-0">
									    <img class="img-fluid" src="<?=base_url() . 'assets/uploads/logos/' . $settings->logo;?>" alt="LMS">
                                    </div>
                                    <div class="col-md-6">
                                        <h5>Let's talk about the future of the internet</h5>
                                        <p class="mb-5 text-secondary">We're here to answer your questions and discuss
                                            the decentralized future of the internet.
                                        </p>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class>
                                        <p class="mb-5 text-secondary"><bold>It is necessary to read this document to understand how the personal information we ask you to submitted by you is used. As we update and expand our services, this policy may undergo a change, so please refer back to it periodically. The terms and conditions to be agreed by you are as follows:</bold>
                                        </p>
                                        
                                        <p class="mb-5 text-secondary">We're here to answer your questions and discuss
                                            the decentralized future of the internet.
                                        </p>
                                        
                           </div>
                             <div class>
                                        <h5>Background</h5>
                                        <p class="mb-5 text-secondary">We're here to answer your questions and discuss
                                            the decentralized future of the internet.
                                        </p>
                                        
                            </div>
                            <div class>
                                        <h5>Let's talk about the future of the internet</h5>
                                        <p class="mb-5 text-secondary">We're here to answer your questions and discuss
                                            the decentralized future of the internet.
                                        </p>
                                        
                           </div>
                             <div class>
                                        <h5>Let's talk about the future of the internet</h5>
                                        <p class="mb-5 text-secondary">We're here to answer your questions and discuss
                                            the decentralized future of the internet.
                                        </p>
                                        
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>