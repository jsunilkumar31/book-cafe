<div id="content-page" class="content-page">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <marquee><p>Currently we are available in Bangalore only.</p></marquee>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class=" ">
                    <div class="">
                        <section class="vertical-center-4 slider slideritems">
                            <div>
                                <img src="https://via.placeholder.com/1000x200?text=1">
                            </div>
                            <div>
                                <img src="https://via.placeholder.com/1000x200?text=2">
                            </div>
                            <div>
                                <img src="https://via.placeholder.com/1000x200?text=3">
                            </div>
                            <div>
                                <img src="https://via.placeholder.com/1000x200?text=4">
                            </div>
                            <div>
                                <img src="https://via.placeholder.com/1000x200?text=5">
                            </div>
                            <div>
                                <img src="https://via.placeholder.com/1000x200?text=6">
                            </div>
                            <div>
                                <img src="https://via.placeholder.com/1000x200?text=7">
                            </div>
                            <div>
                                <img src="https://via.placeholder.com/1000x200?text=8">
                            </div>
                            <div>
                                <img src="https://via.placeholder.com/1000x200?text=9">
                            </div>
                            <div>
                                <img src="https://via.placeholder.com/1000x200?text=10">
                            </div>
                        </section>
                    </div>
                </div>

                <div class="iq-card">
                    <div class="iq-card-body">

                        <section class="py-5">

                            <div class="container">
                                <h2 class="mb-4 text-center">Book A Plan</h2>
                                <p class="lead mb-5 text-center">We've designed a simple, efficient process for Renting A Book. Here's how it works.</p>
                                <div class="row">
                                    <div class="col-md-4">
                                        <img class="img-fluid" src="<?= base_url() . 'assets/uploads/logos/' . $settings->logo; ?>" alt="">
                                    </div>
                                    <div class="col-md-8 mt-3 mt-md-0">
                                        <div class="d-flex mb-2">
                                            <span class="display-4 mr-4">1</span>
                                            <div>
                                                <h3>Subscribe from A Plan</h3>
                                                <p>Using our Website, you can move your data to be stored our decentralized network with simple drag &amp; drop.</p>
                                            </div>
                                        </div>
                                        <div class="d-flex mb-2">
                                            <span class="display-4 mr-4">2</span>
                                            <div>
                                                <h3>Rent A Book</h3>
                                                <p>We want to make sure that you can keep using the software that you use to manage your business.</p>
                                            </div>
                                        </div>
                                        <div class="d-flex">
                                            <span class="display-4 mr-4">3</span>
                                            <div>
                                                <h3>Get it Delivered</h3>
                                                <p>As with all innovative technologies, sometimes unpredictable things will happen, and you can always count on our support to solve issues for you.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="container">
                                
                                <div class="row m-4 pb-4">

                                    <div class="col-lg-3 col-md-6 col-sm-12">
                                        <div class="iq-card">
                                            <div class="iq-card-body border text-center rounded">
                                                <span class="font-size-16 text-uppercase">Standard</span>
                                                <h2 class="mb-4 display-5 font-weight-bolder ">&#8377; 250<small
                                                        class="font-size-14 text-muted">/ Month</small></h2>
                                                <ul class="list-unstyled text-left font-size-13 mb-0">
                                                    <li>Registration &#8377;250</li>
                                                    <li>Refundable Deposit &#8377;800</li>
                                                    <li>Unlimited Renting</li>
                                                    <li>1 Free Delivery per week</li>
                                                </ul>
                                                <a href="https://rzp.io/i/Bi2W1N1Km" target="_blank" class="btn btn-primary mt-5">Start Plan</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6 col-sm-12">
                                        <div class="iq-card bg-primary text-white">
                                            <div class="iq-card-body border text-center rounded">
                                                <span class="font-size-16 text-uppercase">Permium</span>
                                                <h2 class="mb-4 display-5 font-weight-bolder text-white">&#8377;
                                                    350<small class="font-size-14 text-muted text-white">/ Month</small>
                                                </h2>
                                                <ul class="list-unstyled text-left font-size-13 mb-0">
                                                    <li>Registration &#8377;250</li>
                                                    <li>Refundable Deposit &#8377;1200</li>
                                                    <li>Unlimited Renting</li>
                                                    <li>1 Free Delivery per week</li>
                                                </ul>
                                                <a href="https://rzp.io/i/RD9KF6y" target="_blank" class="btn btn-white mt-5">Start Plan</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6 col-sm-12">
                                        <div class="iq-card">
                                            <div class="iq-card-body border text-center rounded">
                                                <span class="font-size-16 text-uppercase">Family</span>
                                                <h2 class="mb-4 display-5 font-weight-bolder ">&#8377; 450<small
                                                        class="font-size-14 text-muted">/ Month</small></h2>
                                                <ul class="list-unstyled text-left font-size-13 mb-0">
                                                    <li>Registration &#8377;250</li>
                                                    <li>Refundable Deposit &#8377;1600</li>
                                                    <li>Unlimited Renting</li>
                                                    <li>1 Free Delivery per week</li>
                                                </ul>
                                                <a href="https://rzp.io/i/OjB5JK10" target="_blank" class="btn btn-primary mt-5">Start Plan</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6 col-sm-12">
                                        <div class="iq-card">
                                            <div class="iq-card-body border text-center rounded">
                                                <span class="font-size-16 text-uppercase">Corporate</span>
                                                <h2 class="mb-4 display-6 font-weight-bolder ">Call Us<small
                                                        class="font-size-14 text-muted">&nbsp;</small></h2>
                                                <ul class="list-unstyled text-left font-size-13 mb-0">
                                                    <li>Call us at 9980394960</li>
                                                    <li>Mail us - @ astiware@gmail.com</li>
                                                    <li>&nbsp;</li>
                                                </ul>
                                                <a href="<?php echo base_url('contact'); ?>" class="btn btn-primary mt-5">Contact Us</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>