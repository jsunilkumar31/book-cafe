<div id="content-page" class="content-page">
    <div class="container-fluid">
        
        <div class="row">
            <div class="col-lg-12">
                <div class="iq-card">
                    <div class="iq-card-body">
                       
                        <section class="py-5">
                            <h2 class="mb-5 text-center">Contact Us</h2>
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-6 mb-3 mb-md-0">
									    <img class="img-fluid" src="<?=base_url() . 'assets/uploads/logos/' . $settings->logo;?>" alt="LMS">
                                    </div>
                                    <div class="col-md-6">
                                        <h5>Let's talk about the future of the internet</h5>
                                        <p class="mb-5 text-secondary">We're here to answer your questions and discuss
                                            the decentralized future of the internet.</p>
                                        <div>
                                            <div class="d-flex">
                                                <p class="text-secondary"><i class="fa fa-home"></i>  <?=$settings->title?> </p>
                                            </div>
                                            <div class="d-flex">
                                                <p class="text-secondary"><i class="fa fa-map-marker"></i>  <?=$settings->address?></p>
                                            </div>
											<div class="d-flex">
                                                <p class="text-secondary"><i class="fa fa-phone"></i>  <?=$settings->phone?></p>
                                            </div>
                                            <div class="d-flex">
                                                <p class="text-secondary"><i class="fa fa-envelope"></i>  <?=$settings->email?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>