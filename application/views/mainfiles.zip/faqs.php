<div id="content-page" class="content-page">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="iq-card">
                    <div class="iq-card-body">

                        <section class="py-5">
                            <h2 class="mb-5 text-center">FAQ's</h2>
                            <div class="container">
                                <div class="row mb-5">
                                    <div class="col-md-6 mb-3 mb-md-0">
                                        <img class="img-fluid" src="<?= base_url() . 'assets/uploads/logos/' . $settings->logo; ?>" alt="LMS">
                                    </div>
                                    <div class="col-md-6">
                                        <h5>Let's talk about the future of the internet</h5>
                                        <p class="mb-5 text-secondary">We're here to answer your questions and discuss
                                            the decentralized future of the internet.
                                        </p>

                                    </div>
                                </div>

                                <div class="row mb-5">
                                    <div class="col-lg-6">
                                        <div class="iq-accordion career-style faq-style  ">
                                            <div class="iq-card iq-accordion-block accordion-active">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> What is BooksCafe? </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                        BooksCafe is an online rental portal (<?php echo base_url(); ?>), which gives the member access to thousands of books, spread across multiple categories. There are no membership plans and as an introductory offer you do not pay for any one time security deposit (refundable or non refundable) unlike other book rental websites. The members can rent one book at a time and keep it until the rental period. We provide free delivery and pick-up of books anywhere in Bangalore.
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> What are the book categories available? </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                        We offer our members the choice of books spread across 16 broad categories to find the book of their choice with ease.
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span>Do you have multiple copies of a particular book?</span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                        We strive to keep multiple copies of a book based on our assessment of the demand and popularity of a particular book. Each book will have a status which will let the member know whether a copy of the desired book is available or not.
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span>Why should I become a member of BooksCafe?  </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <ul class="mb-0">
                                                        <li>Affordability: Get direct access to thousands of books at a very affordable price. There are no membership plans and as an introductory offer you do not pay for any one time security deposit (refundable or non refundable) unlike other book rental websites. You only pay the rent (reading fee) of the book. We are committed to maintain full transparency in dealing with you.</li>
                                                        <li>Choice: Choose from a huge database of books spread across multiple categories. The database is constantly expanding to include more books based upon members’ feedback, new releases and other events in the universe of books.</li>
                                                        <li>Availability: Multiple copies of books available in order to minimize the waiting time.</li>
                                                        <li>Delivery: Free home delivery and pick-up, with delivery date guaranteed.</li>
                                                        <li>Member-centric: User-friendly website for easy navigation and search of books. Warm and friendly customer service to resolve any queries that you may have.</li>
                                                        <li>Pay As You Read: You can rent one book at a time. However, there are no limitations on the number of books you can rent in a month.</li>
                                                        <li>Plentiful Rental period: We offer ample number of days that you can keep a book with you. Depending upon the book our rental period usually lasts anywhere between 7 to 35 days. However we request you to return the book in a reasonable amount of time since other members may also be in the waiting list. Usually we will send a reminder for return on the 7<sup>th</sup></li>
                                                        <li>Interactive: We encourage members to provide feedback, reviews and ratings for the books, which can facilitate other members to make more informed choices. We also provide our own recommendations and suggestions to members, based on their profile and rental history.</li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> How much can I save?  </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                        Members can typically see a savings of 40% to 75% over new books. Some members will see even greater savings of up to 85 or 90%. Just do a quick search of your books and you’ll see for yourself.
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> How long will it take for my book to arrive?  </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                        As with any e-commerce platform, the logistics cost forms a significant part of the overall cost and is the number one priority for a businesses’ bottom line. Therefore, with the objective of keeping logistics costs under check so that we can pass on the benefit in form of low rental fee to our members, we arrange delivery & pick-up of books only on Saturday & Sunday. Once you place an order – after a 24 hour processing period (excluding weekends and major holidays) – it will be delivered to you the following Saturday/Sunday. However, we strongly recommend to please provide yourself ample time to get your books before you need them.

                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block accordion-active">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> What kind of condition are the books in? </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                        All books are in an acceptable used, like new or new condition. We strive to provide you with high quality books similar to new and used books. After all, we’d like to rent the book to someone else once you’re done with it, so it’s in our interest to provide quality books.

                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> What if I need to keep my book longer than the rental period?  </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                        Our rental periods should provide ample time for you to complete your reading, but if you find yourself needing to extend your rental period or re-rent the book altogether, simply call us. You can extend for an additional 7 days (grace period), beyond which you can re-rent the book.

                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span>Will I be charged more if I am late with the return of the book? </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                        We understand that at times owing to your other commitments your book reading may be deprioritized and therefore we ensure you get ample time (rental period) for the books. Depending upon the book our rental period usually lasts anywhere between 7 to 35 days. However, we expect you to return the book as soon as you have finished it reading since other members may also be in the waiting list. There are however no late fee charges.

                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> Do I need to have an account at Rent a Book (www.bookscafe.co.in)?  </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">

                                                        Yes. For shipping and email notification purposes, you need to register. It’s absolutely free. You can also login to your account to check your rental history, rental status, etc.
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> Is there a membership fee or any other kind of fee?  </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                        Absolutely not. We don’t believe in gimmicky fees or confusing plans. Just rent the books you need when you need them for a low price.

                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> What are the payment options available? </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                        We accept cash payments only. Inform us when you have finished reading and we will pick the book and you pay only the rent (reading fee) to the pick-up executive for the book you read.

                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> Will my personal information be BooksCafe?  </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                        Yes, absolutely! We do not rent, sell or disclose any of our customers’ personal information to third parties.

                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="iq-accordion career-style faq-style  ">
                                            <div class="iq-card iq-accordion-block accordion-active">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> What is the billing cycle? </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                        We operate on Pay As You Read model thereby saving you from hassles of automatic deduction of subscription fees depending upon your subscription billing cycles. We are committed to maintain full transparency in dealing with you and you only pay for the rent of the book.
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> How do I see my billing history?  </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                        You can view your Billing History by visiting the “Billing History” area of the “My Account” section.
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span>After becoming a member when will I start receiving books? </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                        As soon as your registration process is completed, you can order or add books to your queue depending upon the availability. Once your order is confirmed please allow us a 24 hour processing period (excluding weekends and major holidays) following which your book will be delivered on upcoming Saturday/Sunday.
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> Can I track the status of delivery? </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                        You can log in to your account and track which book has been dispatched for you. We cannot however provide the precise time of delivery. You will also receive an email from us once a book is dispatched.</p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> How do I search for a book on the website?   </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                        The website has a comprehensive ‘Search’ feature available at the top of most pages.
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> What if I do not receive a book?  </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                        We do our best to ensure we track your books and get them to you on time. In the event that we have dispatched the book and it has not reached you by the promised day we request you to please contact us and we will immediately resolve the problem.
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> What if I lose or damage a book?   </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                       We expect you to maintain the book as you take care of your personal belongings. However, in such an eventuality you will have to pay us the cost of the book.
                                                    </p>
                                                </div>
                                            </div>
                                            
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span>Will I get the book at the top of my queue?   </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                       We will strive to deliver the book based on the priority set by you but it is subject to availability. Books with status as New Addition may have a longer waiting period because of higher demand.
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> What if I receive a wrong delivery?   </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                       Please contact us and we will immediately resolve the problem.
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> How do I get a quote?    </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                    Simply type in Title or Author into the search box on any of our pages. Click on the book you need and the rental price will be displayed.   
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> How do I return my books when I'm done with them?   </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                    Simply click on the “Return Book” button against your order history by visiting the “My Account” section on our website or you may simply call us and notify that you intend to return the book and we will arrange a pick-up executive to collect book from your address. As we are accepting only payments in cash, you may kindly pay the rent (reading fee) to the pick-up executive and receive an invoice for the payment made against your order. When we receive your book, your account will be updated to show the books were returned and you’ll receive a confirmation email. This return process completes the rental cycle and clears your account.   
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="iq-card iq-accordion-block ">
                                                <div class="active-faq clearfix">
                                                    <div class="container-fluid">
                                                        <div class="row">
                                                            <div class="col-sm-12"><a class="accordion-title"><span> How can I ensure whether Rent a Book has really received the book that was collected from me?   </span> </a></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="accordion-details">
                                                    <p class="mb-0">
                                                    We will update your “Order History” at the end of the pick-up cycle. You can view this update by visiting the “My Account” section.   
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5">
                                    <p>Have more questions? Feel free to email us at <?=$settings->email?> We look forward to hear from you!
                                    </p>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>